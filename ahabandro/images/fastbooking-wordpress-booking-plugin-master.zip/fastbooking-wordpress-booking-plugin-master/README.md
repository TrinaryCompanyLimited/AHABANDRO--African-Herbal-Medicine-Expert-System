

## Installation

You can clone from this repository



(If you want to test backend, just leave email to get access)

## Contribute

Found any bugs? Feel free to contribute by creating a [pull request](https://github.com/gorpoghosyan89/fastbooking-wordpress-booking-plugin.git
