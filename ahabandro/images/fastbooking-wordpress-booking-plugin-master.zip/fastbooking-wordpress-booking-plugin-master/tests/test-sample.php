<?php
/**
 * Class SampleTest
 *
 * @package AweBooking
 */

/**
 * Sample test case.
 */
class SampleTest extends WP_UnitTestCase {
	/**
	 * Set up the test fixture.
	 */
	public function setUp() {
		parent::setUp();
	}

	/**
	 * A single example test.
	 */
	public function testSample() {
		// Replace this with some actual testing code.
		$this->assertTrue( true );
	}
}
