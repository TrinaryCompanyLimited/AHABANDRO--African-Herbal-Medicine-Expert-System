<?php
namespace AweBooking\Model;

class Fee {

}
