<?php
namespace AweBooking\Cart\Exceptions;

class Cart_Already_Stored_Exception extends \RuntimeException {}
