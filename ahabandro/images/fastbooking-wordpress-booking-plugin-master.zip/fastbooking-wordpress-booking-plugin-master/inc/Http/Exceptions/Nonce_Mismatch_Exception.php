<?php
namespace AweBooking\Http\Exceptions;

class Nonce_Mismatch_Exception extends \Exception {}
