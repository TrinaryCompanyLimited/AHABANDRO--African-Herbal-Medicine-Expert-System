<?php
namespace AweBooking\Pricing;

class Currency_Mismatch_Exception extends \RuntimeException {}
