<?php
namespace AweBooking\Admin\Forms\Exceptions;

class ValidationException extends \RuntimeException {}
