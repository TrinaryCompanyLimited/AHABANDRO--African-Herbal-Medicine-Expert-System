/// <reference path="./types/Main.d.ts" />
import { Bootstrap } from "./bootstrap/Bootstrap";

new Bootstrap().init();