interface SpeakConfigInterface {
    isRef: boolean;
}