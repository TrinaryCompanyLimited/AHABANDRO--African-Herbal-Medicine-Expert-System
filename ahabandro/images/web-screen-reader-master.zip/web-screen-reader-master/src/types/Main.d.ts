/// <reference path="./SpeakConfigInterface.d.ts" />
