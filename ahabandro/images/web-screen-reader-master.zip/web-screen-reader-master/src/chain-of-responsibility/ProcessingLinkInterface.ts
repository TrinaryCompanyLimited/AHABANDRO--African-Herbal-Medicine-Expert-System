export interface ProcessingLinkInterface {
    setSuccessor(successor: ProcessingLinkInterface): void;
}