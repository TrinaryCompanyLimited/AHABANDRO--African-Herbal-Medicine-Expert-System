jQuery(document).ready(function($){
	/*
	 * wp server side object name: seedobj
	 */
	
	console.log("I'm in seed.js");
});