const $ = window.jQuery;

$(function() {
  // ...
});
