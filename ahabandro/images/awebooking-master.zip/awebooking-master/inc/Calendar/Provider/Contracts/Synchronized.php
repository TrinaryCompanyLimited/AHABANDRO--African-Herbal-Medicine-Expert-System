<?php
namespace AweBooking\Calendar\Provider\Contracts;

interface Synchronized {}
