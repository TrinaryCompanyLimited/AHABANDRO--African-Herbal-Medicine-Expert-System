<?php
namespace AweBooking\Cart\Exceptions;

class Unknown_Model_Exception extends \RuntimeException {}
