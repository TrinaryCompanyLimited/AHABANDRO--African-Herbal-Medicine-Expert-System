<tr>
	<td>
		<table class="footer" align="center" width="570" cellpadding="0" cellspacing="0">
			<tr>
				<td class="content-cell" align="center">
					<?php echo esc_html( apply_filters( 'awebooking/email_footer', awebooking_option( 'email_copyright' ) ) ); ?>
				</td>
			</tr>
		</table>
	</td>
</tr>
