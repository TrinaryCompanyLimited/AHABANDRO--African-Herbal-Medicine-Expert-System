<tr>
	<td class="header">
		<a href="<?php echo esc_url( apply_filters( 'awebooking/email_header_url', get_site_url() ) ); ?>">
			<?php echo esc_html( apply_filters( 'awebooking/email_header', get_bloginfo( 'name' ) ) ); ?>
		</a>
	</td>
</tr>
