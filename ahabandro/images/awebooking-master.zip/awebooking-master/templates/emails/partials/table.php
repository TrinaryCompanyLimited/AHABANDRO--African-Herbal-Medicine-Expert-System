<div class="table">
	<?php echo AweBooking\Support\Markdown::parse( $slot ); ?>
</div>
